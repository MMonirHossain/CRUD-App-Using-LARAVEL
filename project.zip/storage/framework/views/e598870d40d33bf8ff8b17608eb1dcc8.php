<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    
    <title>CRUD APP</title>
</head>
<body>
  
    <header class="d-flex justify-content-center py-3">
        <ul class="nav nav-pills">
          <li class="nav-item"><a href="<?php echo e(route('root')); ?>" class="nav-link active" aria-current="page">Home</a></li>
          <li class="nav-item"><a href="<?php echo e(route('posts.index')); ?>" class="nav-link">Posts</a></li>
          
        </ul>
    </header>

    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
      

      <footer class="py-3 my-4">
        <ul class="nav justify-content-center border-bottom pb-3 mb-3">
          <li class="nav-item"><a href="<?php echo e(route('root')); ?>" class="nav-link px-2 text-body-secondary">Home</a></li>
          <li class="nav-item"><a href="<?php echo e(route('posts.index')); ?>" class="nav-link px-2 text-body-secondary">Posts</a></li>
        </ul>
        <p class="text-center text-body-secondary">&copy; Third Eye, Inc</p>
      </footer>

      
      <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
  
</body>
</html><?php /**PATH G:\php\crud-app\resources\views/layouts/master.blade.php ENDPATH**/ ?>