

<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header">
            <div class="row">
                <div class="col-8">
                    <h1><?php echo e($post->title); ?></h1>
                    <p>Category : <?php echo e($post->category->name); ?>. Created Date: <?php echo e(date('d-m-Y',strtotime($post->created_at))); ?></p>
                </div>            
                <div class="col-4">
                    <div class="float-end">
                        <a href="<?php echo e(route('posts.index')); ?>" class="btn btn-primary">Back</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="text-center">
                <img height="200px" src="<?php echo e(asset('storage/'.$post->image)); ?>" alt="">
            </div>
            <p><?php echo e($post->description); ?></p>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\php\crud-app\resources\views/show.blade.php ENDPATH**/ ?>