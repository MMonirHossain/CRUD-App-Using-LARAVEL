

<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="card">
            <div class="card-header">
                Trashed Posts
                <div class="float-end">
                    <a href="<?php echo e(route('posts.index')); ?>" class="btn btn-primary">Back</a>
                </div>
            </div>
            <div class="card-body">
                <table class="table">
                    <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Title</th>
                        <th scope="col">Description</th>
                        <th scope="col">Category</th>
                        <th scope="col">Image</th>
                        <th scope="col">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($post->id); ?></th>
                            <td><?php echo e($post->title); ?></td>
                            <td><?php echo e($post->description); ?></td>
                            <td><?php echo e($post->category->name); ?></td>
                            <td>
                                <img height="100px" src="<?php echo e(asset('storage/'.$post->image)); ?>" alt="">
                            </td>
                            <td>
                                <div class="d-flex">
                                    <a href="<?php echo e(route('posts.restore',$post->id)); ?>" class="btn btn-success btn-sm">Restore</a>
                                    <form action="<?php echo e(route('posts.force_delete',$post->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                    </form>                                    
                                </div>
                                
                            </td>
                        </tr> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               
                    </tbody>
                </table>
            </div>
        </div>        
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\php\crud-app\resources\views/trashed.blade.php ENDPATH**/ ?>