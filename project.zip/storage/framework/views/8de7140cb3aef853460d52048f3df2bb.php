

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            Edit post
            <div class="float-end">
                <a href="<?php echo e(route('posts.index')); ?>" class="btn btn-success">Back</a>
            </div>
        </div>
        <div class="card-body">

            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger"><?php echo e($error); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>               
            <?php endif; ?>

            <form action="<?php echo e(route('posts.update',$post->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-group">
                    <label for="" class="form-label">Title</label>
                    <input type="text" name="title" class="form-control" value="<?php echo e($post->title); ?>">
                </div>
                <div class="form-group">
                    <label for="" class="form-label">Description</label>
                    <textarea name="description" id="" cols="30" rows="10" class="form-control"><?php echo e($post->description); ?></textarea>
                </div>
                <div class="form-group">
                    <label for="" class="form-label">Image</label>
                    <div><img src="<?php echo e(asset('storage/'.$post->image)); ?>" alt="" height="200px"></div>
                    <input type="file" class="form-control" name="image">
                </div>
                <div class="form-group">
                    <label for="" class="form-label">Category</label>
                    <select name="category_id" id="" class="form-control">
                        <option value="">Select</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php echo e($category->id==$post->id ? 'selected':''); ?> value=<?php echo e($category->id); ?>><?php echo e($category->name); ?></option>                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group">
                    <button class="btn btn-success mt-5">Submit</button>
                </div>

            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\php\crud-app\resources\views/edit.blade.php ENDPATH**/ ?>