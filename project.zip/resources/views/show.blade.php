@extends('layouts.master')

@section('content')

    <div class="card">
        <div class="card-header">
            <div class="row">
                <div class="col-8">
                    <h1>{{$post->title}}</h1>
                    <p>Category : {{$post->category->name}}. Created Date: {{date('d-m-Y',strtotime($post->created_at))}}</p>
                </div>            
                <div class="col-4">
                    <div class="float-end">
                        <a href="{{route('posts.index')}}" class="btn btn-primary">Back</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="text-center">
                <img height="200px" src="{{asset('storage/'.$post->image)}}" alt="">
            </div>
            <p>{{$post->description}}</p>
        </div>
    </div>

@endsection