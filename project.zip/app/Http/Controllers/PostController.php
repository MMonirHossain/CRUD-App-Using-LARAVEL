<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;
use App\Models\Category;
use File;

class PostController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {   
        //$posts = Post::all();
        $posts = Post::paginate(4);
        return view('index',compact('posts'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $categories = Category::all();
        return view('create',compact('categories'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            "title"=>['required','max:255'],
            "description"=>['required'],
            "category_id"=>['required','integer'],
            "image"=>['required','image','max:2048']
        ]);

        $filename = time().'_'.$request->image->getClientOriginalName();
        $filepath = $request->image->storeAs('/uploads',$filename);

        $post = new Post();
        $post->title = $request->title;
        $post->description = $request->description;
        $post->category_id = $request->category_id;
        $post->image = $filepath;
        $post->save();

        return redirect()->route('posts.index');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {   
        $post = Post::findOrFail($id);
        return view('show',compact('post'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {   
        $categories = Category::all();
        $post = Post::findOrFail($id);
        return view('edit',compact('post','categories'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {   
        $request->validate([
            "title"=>['required','max:255'],
            "description"=>['required'],
            "category_id"=>['required','integer'],
        ]);

        $post = Post::findOrFail($id);

        if($request->hasFile('image')){
            $request->validate([
                "image"=>['required','image','max:2048']
            ]);
            $filename = time().'_'.$request->image->getClientOriginalName();
            $filepath = $request->image->storeAs('/uploads',$filename);
            $File::delete(public_path('storage/'.$post->image));
            $post->image = $filepath;
        }
        
        $post->title = $request->title;
        $post->description = $request->description;
        $post->category_id = $request->category_id;

        $post->save();
        return redirect()->route('posts.index');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $post = Post::findOrFail($id);
        
        $post->delete();
        return redirect()->route('posts.index');
    }

    public function trashed(){
        $posts = Post::onlyTrashed()->get();
        return view('trashed',compact('posts'));
    }

    public function restore(string $id){
        $post = Post::onlyTrashed()->findOrFail($id);
        $post->restore();
        return redirect()->back();

    }

    public function force_delete(string $id){
        $post = Post::onlyTrashed()->findOrFail($id);
        File::delete(public_path('storage/'.$post->image));
        $post->forceDelete();
        return redirect()->back();
    }
}
