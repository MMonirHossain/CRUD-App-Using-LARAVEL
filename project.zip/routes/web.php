<?php

use Illuminate\Support\Facades\Route;


use App\Http\Controllers\PostController;

Route::get('/', function () {
    return view('welcome');
})->name('root');

Route::get('posts/trashed',[PostController::class, 'trashed'])->name('posts.trashed');
Route::get('posts/{id}/restore',[PostController::class, 'restore'])->name('posts.restore');
Route::delete('posts/{id}/force_delete',[PostController::class, 'force_delete'])->name('posts.force_delete');

Route::resource('posts', PostController::class);